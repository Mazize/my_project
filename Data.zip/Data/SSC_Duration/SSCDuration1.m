%% plot_SSC_CDC.m
% SSC concentration–duration curves for six watersheds
% Input file (edit only if your path changes):
excelPath = 'C:\Users\Aziz\Desktop\DesktopOctober2024\ExamenDoctoralOctober2024\PhDExamArchives\Article-1\correction\SSC_Flow_Trends_1979-2024\SSCDuration.xlsx';

% ---- Read and prepare data ------------------------------------------------
T = readtable(excelPath, 'PreserveVariableNames', true);

% Watershed names we want to plot (order = legend order)
watersheds = {'Buctouche','Cocagne','South Antigonish','Dunk','Morell','West'};

% Find the corresponding columns in the table (robust to spaces/underscores/extra text)
vn = T.Properties.VariableNames;
vn_plain = regexprep(vn, '[_\s]+', ' ');          % underscores/spaces unified
colIdx = zeros(1,numel(watersheds));
for k = 1:numel(watersheds)
    hit = find(contains(lower(vn_plain), lower(watersheds{k})), 1, 'first');
    if isempty(hit)
        error('Could not find a column containing "%s" in the spreadsheet.', watersheds{k});
    end
    colIdx(k) = hit;
end

% Numeric matrix: rows=time, cols=watersheds (mg/L)
Y = table2array(T(:, colIdx));

% ---- Plot SSC concentration–duration curves -------------------------------
[ret, hFig] = duration_plot_ssc(Y, ...
    'Legend', watersheds, ...
    'Title',  'SSC concentration–duration curves', ...
    'x_label','Frequency of exceedance (%)', ...
    'y_label','SSC (mg L^{-1})', ...
    'PlottingPosition','weibull', ...      % P_i = 100*i/(n+1)
    'LogY', true, ...
    'RemoveNonPositive', true, ...
    'LineWidth', 1.8);

% ---- Save figure next to the Excel file -----------------------------------
[outDir, ~, ~] = fileparts(excelPath);
print(hFig, '-dpng', '-r600', fullfile(outDir, 'SSC_Duration_Curves.png'));
print(hFig, '-dpdf', '-r600', fullfile(outDir, 'SSC_Duration_Curves.pdf'));

% ---- Summarize values at 5/50/95% exceedance and save CSV -----------------
exceed = [5 50 95]; % percent
vals = cdc_values_at_exceedance(Y, exceed, 'weibull', true); % rows = exceed, cols = watersheds
summaryTbl = array2table(vals, 'VariableNames', watersheds);
summaryTbl = addvars(summaryTbl, exceed(:), 'Before', 1, 'NewVariableNames', 'ExceedancePct');
writetable(summaryTbl, fullfile(outDir, 'SSC_CDC_Summary.csv'));

disp('Done. Outputs saved as:');
disp(fullfile(outDir, 'SSC_Duration_Curves.png'));
disp(fullfile(outDir, 'SSC_Duration_Curves.pdf'));
disp(fullfile(outDir, 'SSC_CDC_Summary.csv'));

%% --------------------------------------------------------------------------
function [ret, h] = duration_plot_ssc(y_data, varargin)
% duration_plot_ssc  Plot SSC concentration–duration curves (one curve per column).
%
%   [ret, h] = duration_plot_ssc(y_data, 'Name', value, ...)
%   y_data: numeric matrix (rows = timesteps, cols = watersheds), mg/L

    % Default colour set
    trace_colours = [1 0 0; 0 0 1; 0 1 0; 1 0 1; 0 1 1; 0 0 0; ...
                     0.7 0 0; 0 0.7 0; 0 0 0.7; 0.7 0.7 0; 0.7 0 0.7; 0 0.7 0.7; ...
                     0.8 0 0.8; 1 0 0.5; 0.5 0 0; 0.5 0.5 0];

    p = inputParser;
    p.addRequired('y_data', @(x) isnumeric(x) && ~isempty(x));
    p.addParameter('y_label', 'SSC (mg L^{-1})', @ischar);
    p.addParameter('x_label', 'Frequency of exceedance (%)', @ischar);
    p.addParameter('Title', 'SSC concentration–duration curves', @ischar);
    p.addParameter('SortDirection','descend', @(x) any(strcmpi(x,{'descend','ascend'})));
    p.addParameter('Legend', [], @iscell);
    p.addParameter('TraceColours', trace_colours);
    p.addParameter('LineWidth', 2, @isscalar);
    p.addParameter('ProbabilityOnYAxis', false, @islogical);
    p.addParameter('LogY', true, @islogical);
    p.addParameter('RemoveNonPositive', true, @islogical);
    p.addParameter('PlottingPosition', 'weibull', @(s) any(strcmpi(s,{'weibull','hazen','linear'})));
    p.parse(y_data, varargin{:});

    [~, ncols] = size(y_data);

    legend_str = p.Results.Legend;
    if isempty(legend_str)
        show_legend = false;
        legend_str  = cellstr("Col " + (1:ncols));
    else
        show_legend = true;
        if numel(legend_str) ~= ncols
            error('Legend must have one entry per column.');
        end
    end

    % Choose plotting function (log on SSC axis)
    if p.Results.ProbabilityOnYAxis
        plotfun = @plot;
        if p.Results.LogY, plotfun = @semilogx; end  % log on SSC axis (x)
    else
        plotfun = @plot;
        if p.Results.LogY, plotfun = @semilogy; end  % log on SSC axis (y)
    end

    h = figure('Color','w');
    set(h,'DefaultAxesColorOrder', p.Results.TraceColours, ...
          'DefaultAxesLineStyleOrder', '-|-.|--|:'); hold on;

    % Helper: plotting positions
    function P = pp(n, method)
        switch lower(method)
            case 'weibull', P = 100 * ((1:n) ./ (n + 1));
            case 'hazen',   P = 100 * (((1:n) - 0.5) ./ n);
            case 'linear',  P = linspace(0,100,n);
        end
    end

    % Plot each column
    for j = 1:ncols
        s = y_data(:,j);
        s = s(~isnan(s));
        if p.Results.RemoveNonPositive
            s = s(s > 0);
        end
        if isempty(s), continue; end
        s = sort(s, p.Results.SortDirection);  % descending for exceedance
        n = numel(s);
        P = pp(n, p.Results.PlottingPosition);

        if p.Results.ProbabilityOnYAxis
            plotfun(s, P, 'LineWidth', p.Results.LineWidth);
        else
            plotfun(P, s, 'LineWidth', p.Results.LineWidth);
        end
    end

    grid on; set(gca,'YMinorGrid','on','TickDir','out','Box','on');
    xlabel(p.Results.x_label);
    ylabel(p.Results.y_label);
    title(p.Results.Title);
    if ~p.Results.ProbabilityOnYAxis, xlim([0 100]); else, ylim([0 100]); end

    if show_legend
        legend(legend_str, 'Location','southwest', 'NumColumns',2, 'Box','off');
    end

    % Output: simple percentile table (0:100) per column (ignoring NaNs)
    pr = (0:100)';
    ret.percentiles = [pr prctile(y_data, pr)];
    ret.percentiles_summary = [[{'Percentile'} legend_str]; num2cell(ret.percentiles)];
end

%% --------------------------------------------------------------------------
function vals = cdc_values_at_exceedance(Y, pExceed, method, removeNonPos)
% Return SSC values at specified exceedance percentages (rows=pExceed, cols=series)
    if nargin < 3 || isempty(method), method = 'weibull'; end
    if nargin < 4, removeNonPos = true; end
    ncols = size(Y,2);
    vals = nan(numel(pExceed), ncols);
    for j = 1:ncols
        s = Y(:,j);
        s = s(~isnan(s));
        if removeNonPos, s = s(s > 0); end
        if isempty(s), continue; end
        s = sort(s, 'descend'); % SSC high -> low
        n = numel(s);
        switch lower(method)
            case 'weibull', P = 100 * ((1:n) ./ (n + 1));
            case 'hazen',   P = 100 * (((1:n) - 0.5) ./ n);
            case 'linear',  P = linspace(0,100,n);
        end
        vals(:,j) = interp1(P, s, pExceed, 'linear', 'extrap');
    end
end
